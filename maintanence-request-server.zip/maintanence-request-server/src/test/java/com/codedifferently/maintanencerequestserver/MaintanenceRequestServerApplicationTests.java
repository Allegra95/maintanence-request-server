package com.codedifferently.maintanencerequestserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaintanenceRequestServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
