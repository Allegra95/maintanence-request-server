package com.codedifferently.maintanencerequestserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaintanenceRequestServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaintanenceRequestServerApplication.class, args);
	}

}
